class Main {

    constructor() {
    }

    main() {
        new App().run();
    }

}

new Main().main();