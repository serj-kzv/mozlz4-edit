class Util {
    static isDefinedVar(variable) {
        const isDefined = typeof variable !== 'undefined';

        return isDefined;
    }
}